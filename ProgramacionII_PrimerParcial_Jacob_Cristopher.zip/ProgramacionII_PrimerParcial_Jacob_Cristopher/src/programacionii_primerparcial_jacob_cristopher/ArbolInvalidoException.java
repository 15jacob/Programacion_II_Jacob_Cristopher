package programacionii_primerparcial_jacob_cristopher;

public class ArbolInvalidoException extends IllegalArgumentException
{
    private static final String MESSAGE = "ERROR: La altura indicada no es valida";
    
    public ArbolInvalidoException()
    {
        super(MESSAGE);
    }
}
