package programacionii_primerparcial_jacob_cristopher;

import java.util.Objects;

public abstract class Planta
{
    private String nombre;
    private String ubicacion;
    private Clima tipoClima;
    
    public Planta(String nombre, String ubicacion, Clima tipoClima)
    {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.tipoClima = tipoClima;
    }
    
    private String getNombre()
    {
        return this.nombre;
    }
    
    private String getUbicacion()
    {
        return this.ubicacion;
    }
    
    @Override
    public String toString()
    {
        return "Nombre: " + nombre + " - Ubicacion: " + ubicacion;
    }
    
    @Override
    public boolean equals(Object obj)
    {
        if(this == obj)
        {
            return true;
        }
        
        if(obj == null || getClass() != obj.getClass())
        {
            return false;
        }
        
        Planta other = (Planta) obj;
        
        return getNombre().equals(other.getNombre()) && getUbicacion().equals(other.getUbicacion());
    }
    
    @Override
    public int hashCode()
    {
        return Objects.hash(nombre, ubicacion);
    }
}
