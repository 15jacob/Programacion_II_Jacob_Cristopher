package programacionii_primerparcial_jacob_cristopher;

public class ArbustoInvalidoException extends IllegalArgumentException
{
    private static final String MESSAGE = "ERROR: El ARBUSTO no ha recibido una densidad de foliaje apropiada";
    
    public ArbustoInvalidoException()
    {
        super(MESSAGE);
    }
}