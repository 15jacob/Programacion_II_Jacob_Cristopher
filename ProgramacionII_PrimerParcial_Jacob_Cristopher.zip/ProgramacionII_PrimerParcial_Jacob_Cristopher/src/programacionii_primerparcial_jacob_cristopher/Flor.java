package programacionii_primerparcial_jacob_cristopher;

public class Flor extends Planta
{
    public Temporada tipoTemporadaFlorecimiento;
    
    public Flor(String nombre, String ubicacion, Clima tipoClima, Temporada tipoTemporadaFlorecimiento)
    {
        super(nombre, ubicacion, tipoClima);
        this.tipoTemporadaFlorecimiento = tipoTemporadaFlorecimiento;
    }
    
    @Override
    public String toString()
    {
        return super.toString() + " - Tipo: Flor  - Temporada de Florecimiento: " + tipoTemporadaFlorecimiento.toString();
    }
}
