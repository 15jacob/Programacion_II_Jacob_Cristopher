package programacionii_primerparcial_jacob_cristopher;

public abstract interface Podable
{
    public abstract void podar();
}
