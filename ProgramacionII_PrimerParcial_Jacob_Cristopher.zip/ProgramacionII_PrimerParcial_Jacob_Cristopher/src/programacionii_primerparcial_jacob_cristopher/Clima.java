package programacionii_primerparcial_jacob_cristopher;

public enum Clima
{
    TEMPLADO,
    FRIO,
    LLUVISO,
    HUMEDO,
    ARIDO
}
