package programacionii_primerparcial_jacob_cristopher;

public class Arbol extends Planta implements Podable
{
    private int alturaMaxima;
    
    public Arbol(String nombre, String ubicacion, Clima tipoClima, int alturaMaxima)
    {
        super(nombre, ubicacion, tipoClima);
        
        if(setAlturaMaxima(alturaMaxima) == false)
        {
            throw new ArbolInvalidoException();
        }
    }
    
    private boolean setAlturaMaxima(int alturaMaxima)
    {
        if(alturaMaxima > 0)
        {
            this.alturaMaxima = alturaMaxima;
            return true;
        }
        
        return false;
    }
    
    public void podar()
    {
        System.out.println("Soy un ARBOL, y me han podado!");
    }
    
    @Override
    public String toString()
    {
        return super.toString() + " - Tipo: Arbol - Altura Maxima: " + alturaMaxima + "m";
    }
}
