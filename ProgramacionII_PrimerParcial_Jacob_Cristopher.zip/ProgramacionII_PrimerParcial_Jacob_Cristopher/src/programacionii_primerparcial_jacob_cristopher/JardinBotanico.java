package programacionii_primerparcial_jacob_cristopher;

import java.util.List;
import java.util.ArrayList;

public class JardinBotanico
{
    private String nombre;
    private List<Planta> listaPlantas;
    
    public JardinBotanico(String nombre)
    {
        this.nombre = nombre;
        listaPlantas = new ArrayList();
    }
    
    public void agregarPlanta(Planta planta)
    {
        if(planta != null)
        {
            if(listaPlantas.contains(planta) == true)
            {
                throw new PlantaDuplicadaException();
            }
            
            listaPlantas.add(planta);
        }
    }
    
    public void mostrarPlantas()
    {
        for(Planta planta : listaPlantas)
        {
            System.out.println(planta.toString());
        }
    }
    
    public void podarPlantas()
    {
        for(Planta planta : listaPlantas)
        {
            if(planta instanceof Podable)
            {
                ((Podable) planta).podar();
            }
            else
            {
                System.out.println("Esta planta no es podable!");
            }
        }
    }
    
    public void mostrarNombre()
    {
        System.out.println(this.nombre);
    }
}
