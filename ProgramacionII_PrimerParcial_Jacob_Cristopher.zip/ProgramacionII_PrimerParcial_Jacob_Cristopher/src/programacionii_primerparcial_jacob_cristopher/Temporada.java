package programacionii_primerparcial_jacob_cristopher;

public enum Temporada
{
    PRIMAVERA,
    VERANO,
    OTOÑO,
    INVIERNO
}
