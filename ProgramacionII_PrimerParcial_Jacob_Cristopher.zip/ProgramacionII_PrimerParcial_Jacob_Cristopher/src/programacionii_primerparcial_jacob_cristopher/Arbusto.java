package programacionii_primerparcial_jacob_cristopher;

public class Arbusto extends Planta implements Podable
{
    private int densidadFoliaje;
    private static final int DENSIDAD_MIN = 1;
    private static final int DENSIDAD_MAX = 10;
    
    public Arbusto(String nombre, String ubicacion, Clima tipoClima, int densidadFoliaje)
    {
        super(nombre, ubicacion, tipoClima);
        
        if(setDensidadFoliaje(densidadFoliaje) == false)
        {
            throw new ArbustoInvalidoException();
        }
    }
    
    private boolean setDensidadFoliaje(int densidadFoliaje)
    {
        if(densidadFoliaje <= DENSIDAD_MAX && densidadFoliaje >= DENSIDAD_MIN)
        {
            this.densidadFoliaje = densidadFoliaje;
            return true;
        }
        
        return false;
    }
    
    public void podar()
    {
        System.out.println("Soy un ARBUSTO, y me han podado!");
    }
    
    @Override
    public String toString()
    {
        return super.toString() + " - Tipo: Arbusto  - Densidad de Foliaje: " + densidadFoliaje;
    }
}
