package programacionii_primerparcial_jacob_cristopher;

public class PlantaDuplicadaException extends RuntimeException
{
    private static final String MESSAGE = "ERROR: La planta ya existe en este jardin!";
    
    public PlantaDuplicadaException()
    {
        super(MESSAGE);
    }
}
