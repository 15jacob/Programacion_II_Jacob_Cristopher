package programacionii_primerparcial_jacob_cristopher;

public class ProgramacionII_PrimerParcial_Jacob_Cristopher
{
    public static void main(String[] args)
    {
        JardinBotanico jardinBotanico = new JardinBotanico("Jardin de Plantas de la UTN");
        
        jardinBotanico.mostrarNombre();
        System.out.println("--------------------------------------------------");

        try
        {
            jardinBotanico.agregarPlanta(new Arbol("Platano de Sombra", "Frente", Clima.TEMPLADO, 20));
            jardinBotanico.agregarPlanta(new Arbol("Sauce Lloron", "Frente", Clima.LLUVISO, 25));
            jardinBotanico.agregarPlanta(new Arbusto("Bambu", "Patio", Clima.HUMEDO, 5));
            jardinBotanico.agregarPlanta(new Flor("Orquidea", "Medianera", Clima.LLUVISO, Temporada.VERANO));
            jardinBotanico.agregarPlanta(new Arbusto("Estepicursor", "Vereda", Clima.ARIDO, 9));
        }
        catch(ArbolInvalidoException e)
        {
            System.out.println(e.getMessage());
        }
        catch(ArbustoInvalidoException e)
        {
            System.out.println(e.getMessage());
        }
        catch(PlantaDuplicadaException e)
        {
            System.out.println(e.getMessage());
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
        
        jardinBotanico.podarPlantas();
        System.out.println("--------------------------------------------------");
        jardinBotanico.mostrarPlantas();
        System.out.println("--------------------------------------------------");
    }
}
